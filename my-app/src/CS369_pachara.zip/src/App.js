import React , {useState} from 'react'
 import Input from './Main_component/Input'
import Map from './Main_component/Map'
import ImportImage from './Main_component/ImportImage'
import Showpicture from './Main_component/showPic'
import Mainpage from './Main_component/Mainpage'
import VeiwHotel from './Main_component/VeiwHotel'
import UpdateHotel from './Main_component/UpdateHotel'

import {BrowserRouter ,Route ,Link ,Switch ,useParams} from 'react-router-dom'
import './App.css'
// import Navbar from './component/Navbar'
// import Post from './component/Post'
// import Input from './component/Input'

import Newinput from './Main_component/Newinput'
import NewUpdateHotel from './Main_component/NewUpdateHotel'
let id=1;

const users = [
  {id:1, name:'A'},
  {id:2, name:'B'},
  {id:3, name:'C'}
]

function App() {
  // const [posts,setPost] = useState([]);

  // function addPost(title){
  //   const newPost = { id, title}
  //   setPost([newPost,...posts]);
  //   id+=1;
  //   console.log(posts);
  // }
  
  // function deletePost(id){
  //   const updatedPost = posts.filter((post)=>post.id != id);
  //   setPost(updatedPost)
  // }
  // const Home = () =>  <div> Home Page</div>

  // const About = () =>  <div> About Page</div>

  // const Users = () =>  <div> {users.map(e => 
  // <div key={e.id}> 
  // <Link to={`/${e.id}`}>
  // {e.name}
  // </Link>

  // </div>)}
  
  // </div>


  const User = () => {
    const params = useParams()
    console.log(users[+params.userId-1].name);
    return <div> {users[+params.userId-1].name} 's Dashboard</div>
  } 
  
  const Notfound = () =>  <div> NotFound Page</div>
  return (

//   <BrowserRouter>
//     <nav>
//       <Link to="/">Home </Link>
      
//       <Link to="/user"> Users </Link>
//     </nav>
   

//     <div  >
//       {/* <Newinput/> */}
//       {/* <h1>เพิ่มโรงแรม</h1> */}
//       {/* <ImportImage/> */}
//       {/* <Showpicture  /> */}

//       {/* <Input /> */}
//       {/* <h1>Pachara</h1> */}
//       {/* <h1> <a href="#"> Header </a></h1>
//       <h1> <a href="#"> Content </a></h1>
//       <h1> <a href="#"> Footer </a></h1> */}

//       <Switch>

      
//       <Route exact  path="/">

//           <Mainpage  />

//           <Link to="/insertHotel">
//           <button>add</button>
//           </Link>
        
//       </Route>

//       <Route exact  path="/insertHotel">
//           {/* <Input /> */}
//           <Newinput/>
//           <Link to="/">
//           <button>Back</button>
//           </Link>
    
//       </Route>

//       <Route  path="/UpdateHotel/:id"   >
//           {/* <UpdateHotel /> */}
//           <NewUpdateHotel/>
//       </Route>

//       <Route  path="/VeiwHotel/:id"   >
//           <VeiwHotel />
//       </Route>
// {/* 
//       <Route   path="/user">
//           <Users/>
//       </Route>

     

//       <Route   path="/:userId">
//           <User/>
//       </Route> */}

//       <Route  >
//           <Notfound/>
//       </Route>

//      </Switch>
//      </div>
     
//   </BrowserRouter>  
<BrowserRouter>  
<Route path ='/product/:name' render ={arg =><div>{`pro : ${arg.match.params.name} `}</div>}/>
dww
</BrowserRouter>  
  );
}

export default App;
