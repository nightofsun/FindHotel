import { render } from '@testing-library/react';
import React ,{useState} from 'react'

function  ImportImage() {
    const [selectImg,setSelectImg] = useState([])
    
    const imageHandleChange = (e)=>{
        setSelectImg([])
        if(e.target.files){
            
            const fileArray = Array.from(e.target.files).map((file)=>URL.createObjectURL(file))
            console.log(fileArray);

            setSelectImg((prevImage)=>prevImage.concat(fileArray))
            Array.from(e.target.files).map(
                (file)=>URL.revokeObjectURL(file)
            )
        }
        
    }
    
    const renderPhotos = (source) =>{
        return source.map((photo)=>{
            return <img src={photo} key={photo} style={{width :200,height:200}} />
        })
    }

    return(
        <div> 
            <input type="file" multiple id="file" onChange={imageHandleChange}>
               
            </input>
            <div >
           
                {renderPhotos(selectImg)}
            </div>
        </div>
    )
}

export default ImportImage