import React, { useState } from 'react'
import { Link } from 'react-router-dom';

const initialValues = {
    Namehotel: '',
    District: '',
    Location: '',
    Bedtype: 'เตียงเดี่ยว',
    Nearbylocation: '',
    Price: '',
    Other: '',
};


function Input() {

    let idfileIndex = 0;
    const imageToBase64 = require('image-to-base64');

    const [Input, setInput] = useState(initialValues)
    const [base64Img, setBase64img] = useState([])
    const [selectImg, setSelectImg] = useState([])

    // const sendImg = {
    //     method: 'POST', 
    //     headers: {'Content-Type': 'image/jpeg'},
    //     body:  JSON.stringify(Data),
    //     }




    function onChange(event) {
        // console.log(base64Img);
        const { name, value } = event.target
        // console.log(name);
        // console.log(value);
        setInput({ ...Input, [name]: value });

    }

    const Data = {
        "onwer":"Pachara",
        "nameHotel": Input.Namehotel,
        "district": Input.District,
        "location": Input.Location,
        "bedType": Input.Bedtype,
        "nearbyLocation": Input.Nearbylocation,
        "price": Input.Price,
        "other": Input.Other,
        "images": base64Img[0]
    }

    const requestOption = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Data),
    }

    function postData() {
        console.log(Data);

        let data = fetch('/uploadData', requestOption)

            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }


    function clickme (e){
        console.log(Data);
        setInput(initialValues)
        setSelectImg([])
        setBase64img([])
        console.log("Writing");
    }

    function mySubmitHandler(event) {
        
        console.log(Data);
        setInput(initialValues)
        setSelectImg([])
        setBase64img([])
        console.log(" test");
         postData();

        // event.preventDefault();

        // // alert("You are submitting " + Input );
        // setSelectImg([])
        // setBase64img([])
        // setInput(initialValues)

    }


    const addIndex = (filesArray) => {
        const fileImg = []
        for (let i = 0; i < filesArray.length; i++) {
            fileImg.push({ idfile: idfileIndex, soure: filesArray[i] })
            idfileIndex++;
        }
        return fileImg
    }
    const imgTobase64 = (file) => {
        const base64 = [];
        for (let i = 0; i < file.length; i++) {

            getBase64(file[i])
                .then(result => {
                    file["base64"] = result;
                    idfileIndex++;
                    base64.push({ idfile: idfileIndex, sourceBase64: file.base64 })
                    //  console.log(file.base64);
                })
                .catch(err => {
                    console.log(err);
                });
        }

        return base64
    }

    const getBase64 = file => {
        return new Promise(resolve => {
            let fileInfo;
            let baseURL = "";
            // Make new FileReader
            let reader = new FileReader();

            // Convert the file to base64 text
            reader.readAsDataURL(file);

            // on reader load somthing...
            reader.onload = () => {
                // Make a fileInfo Object
                // console.log("Called", reader);
                baseURL = reader.result;
                //  console.log(baseURL);
                resolve(baseURL);
            };
            //   console.log(fileInfo);
        });
    };



    const imageHandleChange = (e) => {
        // console.log(e.target.files[])
        if (e.target.files) {
            // console.log(e.target.files[0]);
            //  console.log(e.target.files);
            const Base64File = imgTobase64(e.target.files)
            const filesArray = Array.from(e.target.files).map((file) => URL.createObjectURL(file));
            const showImg = addIndex(filesArray)

            // console.log("Base64 : ");
            //  console.log(Base64File);

            // setBase64img(((prevImages) => prevImages.concat(Base64File)));
            setBase64img(prev => [...prev, Base64File])
            setSelectImg(((prevImages) => prevImages.concat(showImg)));

            // setTimeout(()=>{ console.log(Base64File);},3000)
            Array.from(e.target.files).map(
                (file) => URL.revokeObjectURL(file) // avoid memory leak
            );
        }
    };


    const renderPhotos = (soureImg) => {
        // console.log("render");
        //    console.log(base64Img[0]);
        //    console.log(selectImg);
        return soureImg.map(photo => {
            return (
                <div>
                    <img src={photo.soure} key={photo.idfile} style={{ width: 200, height: 200 }} />
                    <button onClick={() => removeImage(photo.idfile)}>X</button>
                </div>
            )
        })
    }

    const removeImage = (idfile) => {

        setBase64img((oldState) => oldState.filter((item) => item.idfile !== idfile));
        // this is the line that you are looking for
        setSelectImg((oldState) => oldState.filter((item) => item.idfile !== idfile));
        //  console.log(base64Img);

    };




    return (

        <div  >


            <div class="image-flex" >

                {renderPhotos(selectImg)}

            </div>

            {/* <form class="main-Grid" action="/uploadmultiple" onSubmit = {mySubmitHandler}  method="post" enctype="multipart/form-data"   > */}

            <form class="main-Grid"   >




                <label class="size-label">
                    <div class="selectImg">
                        {/* <div class ="plus-icon"> + </div> */}
                        {/* <form action="/uploadmultiple" method="post" enctype="multipart/form-data"> */}
                        <input type="file" multiple name="images" id="file" onChange={imageHandleChange} ></input>
                        {/* <button type="submit">Upload</button>
                                    </form> */}
                    </div>
                </label>

                <div class="Input-tag">
                    <input class="flex-item"
                        placeholder="ชื่อโรงแรม" type='text' value={Input.Namehotel} name="Namehotel" onChange={onChange}
                    />
                    <input class="flex-item"
                        placeholder="อำเภอ" type='text' value={Input.District} name="District" onChange={onChange}
                    />
                    <input class="flex-item"
                        placeholder="ที่ตั้ง" type='text' value={Input.Location} name="Location" onChange={onChange}
                    />
                    {/* <input  
                            placeholder = "ชนิดเตียง"type ='text' value ={Input.Bedtype} name = "Bedtype" onChange={onChange}
                            /> */}
                    {/* <label > */}

                    <select class="flex-item" onChange={onChange} name="Bedtype" value={Input.Bedtype}  >
                        <option >เตียงเดี่ยว</option>
                        <option >เตียงคู่</option>

                    </select>
                    {/* </label> */}
                    <input class="flex-item"
                        placeholder="สถานที่ใกล้เคียง" type='text' value={Input.Nearbylocation} name="Nearbylocation" onChange={onChange}
                    />
                    <input class="flex-item"
                        placeholder="ราคา" type='text' value={Input.Price} name="Price" onChange={onChange}
                    />



                    <textarea class="flex-item" rows="5" cols="50"
                        placeholder="ข้อมูลเพิ่มเติม... " type='text' value={Input.Other} name="Other" onChange={onChange}
                    />
                </div>


                <div class="input-button">
                   
                        {/* <input class="pointer" type="submit" value="Submit" /> */}
                        
                        {/* <button  type="submit" >ssss</button> */}
                      
                </div>
                
            </form>
            <button  onClick={mySubmitHandler}  >ssss</button> 
            <button  onClick={clickme} >dddd</button>
        </div>
    )
}


export default Input;