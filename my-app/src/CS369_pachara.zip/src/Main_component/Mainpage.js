import React, { useState,useEffect } from 'react'
import {Link, Route } from 'react-router-dom'

function Mainpage(){


    const [listHotel,setListhotel] = useState([])

    async function loadPic(){
            
        const res = await fetch('/loadPicture/Pachara');
            res.json()
            .then(res => {setListhotel(res) })
            .then(()=>{console.log(listHotel)})
            //  .then(()=>console.log(listHotel[0]))
            
            // .then(res => setimage(res[0].images))
            // .then(()=>console.log(image))
            
            // .then(res => )
            // .then(()=>console.log(image))
         }
         
    useEffect(()=>{
        

         loadPic();

    },[])

    // const hotellist = listHotel.map(item => {
    //  console.log(item);
    //     return 
    //     (
       
    
    //         // <div key={item.images.idfile} >
    //         <div>
    //             Pachara
    //              {/* <Link to={`/VeiwHotel/${item._id}`}>
    //             <img srcSet={item.images}  width="150" height="130" style={{margin: "6px" }}/>
    //             </Link>
                
    //             <div className="name">{item.name}</div>
    //             <div className="address">{item.description}</div>
    //             <div className="shortDetail">{item.shortDetail}</div> */}
              
    //         </div>
          
    //     )
    // })
    
   

    const hotellist = listHotel.map(item => {
        //  console.log(item.status);
        return (
           
           <div>
               {item.status}
            <div key={item._id} style={{display:"flex",flexdirection: "row" , flexwrap: "wrap",  }} >
            <Link to={`/VeiwHotel/${item._id}`}>
            <img srcSet={item.images[0].sourceBase64} width="150" height="130" style={{margin: "6px" }}  />
            </Link>
             </div>
     <div className="name">{item.name}</div>
     <div className="address">{item.description}</div>
     <div className="shortDetail">{item.shortDetail}</div>
     </div>
        )
    })
    
    return(
        <div>
           
            Main Page
        <div style={{display:"flex",flexdirection: "row" , flexwrap: "wrap",  }} >
            {hotellist}
            
            {/* <List/> */}

            </div>
        </div>
    )
}

export default Mainpage