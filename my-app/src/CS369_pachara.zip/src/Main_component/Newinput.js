
import React, { useEffect, useState } from 'react'
import Jumbotron from 'react-bootstrap/Jumbotron';
import Toast from 'react-bootstrap/Toast';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form'
import Col from 'react-bootstrap/Col'
import Row from 'react-bootstrap/Row'
import Pic from '../Picture/Capture.PNG'
import Modal from 'react-bootstrap/Modal'
import { useParams, Link } from 'react-router-dom'
const initialValues = {
      Namehotel: '',
      District: '',
      Location: '',
      Bedtype: 'เตียงเดี่ยว',
      Nearbylocation: '',
      Price: '',
      Shortdetail: '',
      Landmark: '',
      Other: '',
};
const textalert = ["คุณแน่ใจว่าจะกดส่ง","คุณแน่ใจว่าจะเก็บข้อมูลไว้เพื่อนำกลับมาแก้ไข","คุณแน่ใจว่าจะยกเลิก"]

function UpdateHotel() {
    const params = useParams()

    const [listHotel, setListhotel] = useState([])

    const imageToBase64 = require('image-to-base64');

    const [Input, setInput] = useState(initialValues)
    const [base64Img, setBase64img] = useState([])
    const [selectImg, setSelectImg] = useState([])


      let idfileIndex = 0;

      const [Status, setStatus] = useState("");
      const [IndexTextalert,setIndexTextalert] =useState(0);
      const [show, setShow] = useState(false);
      const handleClose = () => setShow(false);
      const handleShow = () => {setShow(true);  }
      const Data = {
            "owner": "Pachara",
            "nameHotel": Input.Namehotel,
            "district": Input.District,
            "location": Input.Location,
            "bedType": Input.Bedtype,
            "nearbyLocation": Input.Nearbylocation,
            "price": Input.Price,
            "other": Input.Other,
            "images": base64Img,
            "shortDetail": Input.Shortdetail,
            "landMark": Input.Landmark,
            "status": Status

      }

      function onChange(event) {

            const { name, value } = event.target
            console.log(name);
            console.log(value);
            setInput({ ...Input, [name]: value });

      }

      const requestOption = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(Data),
      }

      function postData() {

            console.log(Data);
    
            let data = fetch('/uploadData', requestOption)
    
                .then(response => response.json())
                .then(data => {
                    console.log('Success:', data);
                })
                .catch((error) => {
                    console.error('Error:', error);
                });
        }



      function mySubmitHandler(event) {
            handleClose()
            // console.log(Data);
            // const status = setStatus("Waitcheck")

            console.log(Data);
            // console.log(" test");
            postData();
            // setInput(initialValues)
            // setSelectImg([])
            // setBase64img([])

            // // alert("You are submitting " + Input );
            // setSelectImg([])
            // setBase64img([])
            // setInput(initialValues)

      }

      function waitDocontinue(event) {
        

            console.log(Data);

            postData();
            event.preventDefault();
            // setInput(initialValues)
            // setSelectImg([])
            // setBase64img([])
            // setStatus("")
      }


      function dropData(event) {

            event.preventDefault();
            setInput(initialValues)
            // setSelectImg([])
            // setBase64img([])
            // setStatus("")
      }

      const addIndex = (filesArray) => {
            const fileImg = []
            for (let i = 0; i < filesArray.length; i++) {
                  idfileIndex = Math.floor(Math.random() * 10000);
                  fileImg.push({ idfile: idfileIndex, soure: filesArray[i] })
            }
            return fileImg
      }

      const getBase64 = file => {
            return new Promise(resolve => {
                let fileInfo;
                let baseURL = "";
                // Make new FileReader
                let reader = new FileReader();
    
                // Convert the file to base64 text
                reader.readAsDataURL(file);
    
                // on reader load somthing...
                reader.onload = () => {
                    // Make a fileInfo Object
                    // console.log("Called", reader);
                    baseURL = reader.result;
                    //  console.log(baseURL);
                    resolve(baseURL);
                };
                //   console.log(fileInfo);
            });
        };

        const imgTobase64 = (file) => {

            for (let i = 0; i < file.length; i++) {
                const  idfileIndex = Math.floor((Math.random() * 10000));
                getBase64(file[i])
                    .then(result => {
                        file["base64"] = result;
                        setBase64img(prev => [...prev, { idfile: idfileIndex, sourceBase64: file.base64 }])
    
                    })
                    .catch(err => {
                        console.log(err);
                    });
            }
    
        }

      const imageHandleChange = (e) => {
            // console.log(e.target.files[])
            if (e.target.files) {
                  const Base64File = imgTobase64(e.target.files)
                  console.log(Base64File);
            }
      };

      const renderPhotos = (soureImg) => {

            console.log(soureImg);
            // console.log(base64Img);
            return soureImg.map(photo => {
                // console.log(selectImg)
                return (
                    <div>
                        <img src={photo.sourceBase64 || photo.soure} key={photo.idfile} style={{ width: 200, height: 200 }} />
                        <button onClick={() => removeImage(photo.idfile)}>X</button>
                    </div>
                )
            })
        }

      const removeImage = (idfile) => {

            setBase64img((oldState) => oldState.filter((item) => item.idfile !== idfile));
            // this is the line that you are looking for
            setSelectImg((oldState) => oldState.filter((item) => item.idfile !== idfile));
            //  console.log(base64Img);

      };

      

      const Showalert =(props)=>{
       
            console.log(props);
            return (
                  <Modal {...props} >
                  
                  <Modal.Header closeButton>
                    <Modal.Title>Modal heading</Modal.Title>
                  </Modal.Header>
          
                  <Modal.Body>{props.text}</Modal.Body>
          
                  <Modal.Footer>
                    <Button  onClick={handleClose}>
                      Close
                    </Button>
                    <Button  onClick={mySubmitHandler}>
                      Save Changes
                    </Button>
          
                  </Modal.Footer>
          
                </Modal>

            )
      }
   
      
      return (

            <Container>
                  <Row>
                        {renderPhotos(base64Img)}

                  </Row>

                  <Row>


                        <label >
                              <img src={Pic} />
                              <input type="file" style={{ display: 'none' }} multiple name="images" id="file" onChange={imageHandleChange} />

                        </label>

                  </Row>

                  <Row>


                        <Col>

                              <Form.Control type="text" placeholder="ชื่อโรงแรม" value={Input.Namehotel} name="Namehotel" onChange={onChange} />

                              <Form.Control as="select" onChange={onChange} name="Bedtype" value={Input.Bedtype} >
                                    <option>เตียงเดี่ยว</option>
                                    <option>เตียงคู่</option>
                              </Form.Control>

                              <Form.Control type="text" placeholder="คำอธิบายสั้นๆ" value={Input.Shortdetail} name="Shortdetail" onChange={onChange} />




                        </Col>

                        <Col>
                              <Form.Control type="text" placeholder="อำเภอ" value={Input.District} name="District" onChange={onChange} />

                              <Form.Control type="text" placeholder="สถานที่ใกล้เคียง" value={Input.Nearbylocation} name="Nearbylocation" onChange={onChange} />

                              <Form.Control type="text" placeholder="Landmark" value={Input.Landmark} name="Landmark" onChange={onChange} />
                        </Col>
                        <Col>
                              <Form.Control type="text" placeholder="ที่ตั้ง" value={Input.Location} name="Location" onChange={onChange} />

                              <Form.Control type="text" placeholder="ราคา" value={Input.Price} name="Price" onChange={onChange} />

                              <Form.Control type="text" placeholder="ลืมหรือไม่มี" />
                        </Col>

                  </Row>


                  <Row>
                        <Form.Control as="textarea" rows={3} placeholder="ข้อมูลเพิ่มเติม..." style={{ resize: "none" }} value={Input.Other} name="Other" onChange={onChange} />
                  </Row>

                  <Button onClick={()=>{handleShow(); setIndexTextalert(0); setStatus("Waitcheck")} }  > บันทึก </Button>

                  <Button onClick={()=>{handleShow(); setIndexTextalert(1); setStatus("Waitedit")} }> เก็บไว้ </Button>
                  <Button onClick={()=>{handleShow(); setIndexTextalert(2) }}  > ยกเลิก </Button>
                  
            <Showalert show={show} onHide={handleClose} text={textalert[IndexTextalert] } />
            

            </Container>
      )
}

export default UpdateHotel;
