import React, { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
let idfileIndex = 0;
const initialValues = {
    uniqueId: '',
    Namehotel: '',
    District: '',
    Location: '',
    Bedtype: '',
    Nearbylocation: '',
    Price: '',
    Other: ''
};


function UpdateHotel() {
    const params = useParams()

    const [listHotel, setListhotel] = useState([])

    const imageToBase64 = require('image-to-base64');

    const [Input, setInput] = useState(initialValues)
    const [base64Img, setBase64img] = useState([])
    const [selectImg, setSelectImg] = useState([])




    function onChange(event) {

        const { name, value } = event.target
        // console.log(name);
        // console.log(value);
        setInput({ ...Input, [name]: value });

    }


    const Data = {
        "owner":"Pachara",
        "uniqueId": Input.uniqueId,
        "nameHotel": Input.Namehotel,
        "district": Input.District,
        "location": Input.Location,
        "bedType": Input.Bedtype,
        "nearbyLocation": Input.Nearbylocation,
        "price": Input.Price,
        "other": Input.Other,
        "images": base64Img
    }

    const requestOption = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Data),
    }

    function postData() {

        console.log(Data);

        let data = fetch('/updateHotel', requestOption)

            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
            })
            .catch((error) => {
                console.error('Error:', error);
            });
    }


    function onChange(event) {
        console.log(base64Img);
        const { name, value } = event.target
        // console.log(name);
        // console.log(value);
        setInput({ ...Input, [name]: value });

    }


    function mySubmitHandler(event) {

        // console.log();
        postData();

        event.preventDefault();

        // alert("You are submitting " + Input );
        setSelectImg([])
        setBase64img([])
        setInput(initialValues)

    }


    const addIndex = (filesArray) => {
        const fileImg = []
        for (let i = 0; i < filesArray.length; i++) {
            fileImg.push({ idfile: i, soure: filesArray[i] })

        }
        return fileImg
    }

    const getBase64 = file => {
        return new Promise(resolve => {
            let fileInfo;
            let baseURL = "";
            // Make new FileReader
            let reader = new FileReader();

            // Convert the file to base64 text
            reader.readAsDataURL(file);

            // on reader load somthing...
            reader.onload = () => {
                // Make a fileInfo Object
                // console.log("Called", reader);
                baseURL = reader.result;
                //  console.log(baseURL);
                resolve(baseURL);
            };
            //   console.log(fileInfo);
        });
    };

    const imgTobase64 = (file) => {

        for (let i = 0; i < file.length; i++) {

            getBase64(file[i])
                .then(result => {
                    file["base64"] = result;
                    setBase64img(prev => [...prev, { idfile: i, sourceBase64: file.base64 }])

                })
                .catch(err => {
                    console.log(err);
                });
        }

    }

    const imageHandleChange = (e) => {

        if (e.target.files) {
            //  console.log(base64Img)
            //  console.log(e.target.files);

            const Base64File = imgTobase64(e.target.files)
            console.log(Base64File);


        }
    };


    const renderPhotos = (soureImg) => {

        console.log(soureImg);
        // console.log(base64Img);
        return soureImg.map(photo => {
            // console.log(selectImg)
            return (
                <div>
                    <img src={photo.sourceBase64 || photo.soure} key={photo.idfile} style={{ width: 200, height: 200 }} />
                    <button onClick={() => removeImage(photo.idfile)}>X</button>
                </div>
            )
        })
    }

    const removeImage = (idfile) => {

        setBase64img((oldState) => oldState.filter((item) => item.idfile !== idfile));
        // this is the line that you are looking for
        setSelectImg((oldState) => oldState.filter((item) => item.idfile !== idfile));
        //  console.log(base64Img);

    };



    async function loadPic() {



        const res = await fetch(`/loadViewhotel/${params.id}`);
        res.json()
            .then(res => {

                initialValues.uniqueId = params.id
                initialValues.Namehotel = res[0].name
                initialValues.District = res[0].district
                initialValues.Location = res[0].location
                initialValues.Bedtype = res[0].bedType
                initialValues.Nearbylocation = res[0].Nearbylocation
                initialValues.Price = res[0].price
                initialValues.Other = res[0].shortDetail
                const Base64 = res[0].images
                for (let index = 0; index < Base64.length; index++) {
                    delete Base64[index]._id;

                }
                console.log(Base64);
                setBase64img(res[0].images)

                // setSelectImg(res[0].images)

            })
        // .then(()=>{console.log(" after set");})

        //  .then(()=>{console.log(base64Img);})


        // .then(res => setimage(res[0].images))
        // .then(()=>console.log(image))

        // .then(res => )
        // .then(()=>console.log(image))
    }


    useEffect(() => {

        loadPic();

    }, [])


    // console.log(params);
    return (
        <div>
            UpdateHotel

            <div class="image-flex" >

                {renderPhotos(base64Img)}

            </div>

            {/* <form class="main-Grid" action="/uploadmultiple" onSubmit = {mySubmitHandler}  method="post" enctype="multipart/form-data"   > */}

            <form class="main-Grid" onSubmit={mySubmitHandler}     >




                <label class="size-label">
                    <div class="selectImg">
                        {/* <div class ="plus-icon"> + </div> */}
                        {/* <form action="/uploadmultiple" method="post" enctype="multipart/form-data"> */}
                        <input type="file" multiple name="images" id="file" onChange={imageHandleChange} ></input>
                        {/* <button type="submit">Upload</button>
                                    </form> */}
                    </div>
                </label>

                <div class="Input-tag">
                    <input class="flex-item"
                        placeholder="ชื่อโรงแรม" type='text' value={Input.Namehotel} name="Namehotel" onChange={onChange}
                    />
                    <input class="flex-item"
                        placeholder="อำเภอ" type='text' value={Input.District} name="District" onChange={onChange}
                    />
                    <input class="flex-item"
                        placeholder="ที่ตั้ง" type='text' value={Input.Location} name="Location" onChange={onChange}
                    />
                    {/* <input  
                            placeholder = "ชนิดเตียง"type ='text' value ={Input.Bedtype} name = "Bedtype" onChange={onChange}
                            /> */}
                    {/* <label > */}

                    <select class="flex-item" onChange={onChange} name="Bedtype" value={Input.Bedtype}  >
                        <option >{initialValues.Bedtype == 'เตียงเดี่ยว' ? "เตียงเดี่ยว" : "เตียงคู่"}</option>
                        <option >{initialValues.Bedtype != 'เตียงเดี่ยว' ? "เตียงเดี่ยว" : "เตียงคู่"}</option>

                    </select>
                    {/* </label> */}
                    <input class="flex-item"
                        placeholder="สถานที่ใกล้เคียง" type='text' value={Input.Nearbylocation} name="Nearbylocation" onChange={onChange}
                    />
                    <input class="flex-item"
                        placeholder="ราคา" type='text' value={Input.Price} name="Price" onChange={onChange}
                    />



                    <textarea class="flex-item" rows="5" cols="50"
                        placeholder="ข้อมูลเพิ่มเติม... " type='text' value={Input.Other} name="Other" onChange={onChange}
                    />
                </div>


                <div class="input-button">
                  
                        <input class="pointer" type="submit" value="Submit" />
                    
                </div>

            </form>


        </div>
    )
}
export default UpdateHotel