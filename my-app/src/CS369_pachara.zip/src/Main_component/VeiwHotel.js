import React ,{useEffect,useState}from 'react'
import {useParams,Link} from 'react-router-dom'
function VeiwHotel () {
    
    const params = useParams()
    const [listHotel,setListhotel] = useState([])
    
  
    async function loadPic(){
            
        const res = await fetch(`/loadViewhotel/${params.id}`);
            res.json()
            .then(res => setListhotel(res))
            
            // .then(res => setimage(res[0].images))
            // .then(()=>console.log(image))
            
            // .then(res => )
            // .then(()=>console.log(image))
         }
         
    useEffect(()=>{
        
         loadPic();

    },[])

    function deletePost(){
        fetch(`/deleteHotel/${params.id}`)
        .then(res => console.log(res))
    }

    function Picture ( pic){
         console.log(pic)
     return pic.map(e => <div > <img key={e} srcSet={e.sourceBase64} width="150" height="130" style={{margin: "6px" }} /></div> )
    }
    
    const hotellist = listHotel.map(item => {
        return (
           
           <div>
            <div key={item._id} style={{display:"flex",flexdirection: "row" , flexwrap: "wrap",  }} >
                {Picture(item.images)}  
                
             </div>
     <div className="name">{item.name}</div>
     <div className="address">{item.description}</div>
     <div className="shortDetail">{item.shortDetail}</div>
     </div>
        )
    })

    console.log(params);
    return( 
        <div>
    
           
            {hotellist}
            
            <Link to={`/UpdateHotel/${params.id}`}>
            <button >updatePost</button>
            </Link>

            <Link to="/">
            <button onClick={deletePost}>deletePost</button>
            </Link>

           

        </div>
    )
}

export default VeiwHotel
