
import React ,{useEffect, useState} from 'react'

function Showpicture() {

     const [image,setimage] = useState([])
    
    //  function loadPic (){
    //     fetch('/loadPicture/testHotel')
    //     .then(res => res.json())
    //     .then(res => console.log(res))
    //     // .then(res => )
    //     // .then(()=>console.log(image))
    //  }
 
    
    // .then(res => console.log(res))
    // // .then(res => {setimage(res)})
    async function loadPic(){
            
        const res = await fetch('/loadPicture/Pachara');
            res.json()
            .then(res => setimage(res[0].images))
            // .then(()=>console.log(image))
            
            // .then(res => )
            // .then(()=>console.log(image))
         }
         
    useEffect(()=>{
        loadPic();
    },[])
    
    const renderPhotos = (soureImg) =>{

          console.log(soureImg);
          
        return soureImg.map( photo=>{
            return (
            <div> 
            <img src={photo}   />
            
            </div>
            )
        })
    }

    return (
         <div>
              <button onClick={loadPic}>test</button>
            {/* <img src={image}/> */}
            {renderPhotos(image)}
         </div>
  

  
            //  <img src={`data:image/jpeg;base64,${image}`}></img>
  
    );
  }
  
export default Showpicture;