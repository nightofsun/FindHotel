const A = [{index:10 , id:1 , name :"pachara"},{id:2 , name :"pachara"},
            {id:3 , name :"pachara"},{id:4 , name :"pachara"}]
delete A[0].index;

A.map(e => console.log(e))