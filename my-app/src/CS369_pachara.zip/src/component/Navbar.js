import React from 'react'

function Navbar() {
  return (
    
      <header className="Navbar"> facebook</header>
  );
}

export default Navbar;
