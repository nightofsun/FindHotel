import React,{useState,useEffect} from 'react'
import '../App.css';


function C2(){

    const konamicode = [
        'ArrowUp',
        'ArrowUp',
        'ArrowDown',
        'ArrowDown',
        'ArrowLeft',
        'ArrowRight',
        'ArrowLeft',
        'ArrowRight',
        'b',
        'a'
    ]
        
    let index = 0;
    const [Text,setText] = useState('')
    const [Input,setInput] = useState('')

  
function onChange(event){
    
    setInput(event.target.value);

}

function onKeyDown(event){
 event.key === konamicode[index]?index++:index=0
   //console.log(event);

   if(konamicode.length === index){
       console.log("activate konami code");
   }
    // if(event.key === 'Enter' && title){
    //    setText(title)
    //     setInput('');
    // }
    
}


    return(
        <div >
            {document.addEventListener('keydown',onKeyDown)}
        </div>
    )
}

export default C2