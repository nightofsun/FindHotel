import React, {useContext} from "react"
import {MyContext} from "./myContext"

const Winner =({buyNo})=>{
    const context = useContext(MyContext)
    return (
        <>
        {console.log(context)}
        <div>Lotto no : </div>
        <div>Your no : {context.luckyNo}  </div>
        </>
    )
}
export default Winner