import { createContext ,useState} from "react";

const MyContext = createContext();
const {Provider} =MyContext;

const MyProvider = ({children})=>{

    const [luckyNo , setluckyNo] =useState(56)

    const matchNumber = (num)=>{
        return num === luckyNo;
    }

    return (
        <Provider
            value = {{
                luckyNo,
                setluckyNo,
                winLotto : no => matchNumber(no)
            }}
        >
            
            {children}
    
        </Provider>
    );

}

export {MyContext , MyProvider}