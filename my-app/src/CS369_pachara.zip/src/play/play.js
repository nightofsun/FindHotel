
const App =()=>{
  return (
    <MyProvider>
      <Winner buyNo={33}/>
    </MyProvider>
  )
}