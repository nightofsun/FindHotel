const initialValues = {
    Namehotel:'dwadawd',
    District:'',
    Location:'',
    Bedtype:'',
    Nearbylocation:'',
    Price:'',
    Other:''
    
  };


  const data = JSON.stringify({A:initialValues.Namehotel})

  console.log(data);