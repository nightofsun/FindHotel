import React, { useState } from 'react'

import Mainpage from './Main_component/Mainpage'
import VeiwHotel from './Main_component/VeiwHotel'

import { BrowserRouter, Route, Link, Switch, useParams } from 'react-router-dom'
import './App.css'

import Newinput from './Main_component/Newinput'
import NewUpdateHotel from './Main_component/NewUpdateHotel'
import { Button } from 'react-bootstrap'
let id = 1;

const users = [
  { id: 1, name: 'A' },
  { id: 2, name: 'B' },
  { id: 3, name: 'C' }
]

function App() {

  const [posts, setPost] = useState([]);

  function addPost(title) {
    const newPost = { id, title }
    setPost([newPost, ...posts]);
    id += 1;
    console.log(posts);
  }

  function deletePost(id) {
    const updatedPost = posts.filter((post) => post.id != id);
    setPost(updatedPost)
  }

  const Home = () => <div> Home Page</div>

  const About = () => <div> About Page</div>

  const Users = () => <div> {users.map(e =>
    <div key={e.id}>
      <Link to={`/${e.id}`}>
        {e.name}
      </Link>

    </div>)}

  </div>


  const User = () => {
    const params = useParams()
    console.log(users[+params.userId - 1].name);
    return <div> {users[+params.userId - 1].name} 's Dashboard</div>
  }

  const Notfound = () => <div> NotFound Page</div>
  return (

    <BrowserRouter>
      <nav>
        <Link to="/">Home </Link>

        <Link to="/user"> Users </Link>
      </nav>


      <div  >
     

        <Switch>


          <Route exact path="/">
            <Mainpage />

            <Link to="/insertHotel">
              <Button>เพิ่มโรงแรม</Button>

            </Link>

           
          </Route>

          <Route exact path="/insertHotel">
            {/* <Input /> */}
            <Newinput />
           

          </Route>

          <Route path="/UpdateHotel/:id"   >
            {/* <UpdateHotel /> */}
            <NewUpdateHotel />
          </Route>

          <Route path="/VeiwHotel/:id"   >
            <VeiwHotel />
          </Route>
          {/* 
      <Route   path="/user">
          <Users/>
      </Route>

     

      <Route   path="/:userId">
          <User/>
      </Route> */}

          <Route  >
            <Notfound />
          </Route>

        </Switch>

       
      </div>

    </BrowserRouter>

  );
}

export default App;
