import React, { useState, useEffect } from 'react'
import { Link, Route } from 'react-router-dom'
import Icon from '../Picture/emtryImage.png'
import '../App.css'
import { Card, Button, CardImg } from 'react-bootstrap'
function Mainpage() {


    const [listHotel, setListhotel] = useState([])

    async function loadPic() {

        const res = await fetch('/loadPicture/Pachara');
        res.json()
            .then(res => { setListhotel(res) })
            .then(() => { console.log(listHotel) })
       
    }

    useEffect(() => {

        loadPic();

    }, [])

    const styleStatus =( status )=>{

        if(status === 'Public'){
            return {color:"white" ,backgroundColor:"#12B42B" ,textAlign:'center' }
        }
        else if(status === 'Waitedit'){
            return {color:"white" ,backgroundColor:"#EAB405" , textAlign:'center'}
        }
        else if(status === 'Waitcheck'){
            return {color:"white" ,backgroundColor:"#0D8ECC", textAlign:'center'}
        }
        else {

        }

    }

    const hotellist = listHotel.map(item => {
        console.log(item);
        return (

            

            <Card style={{margin: "10px", width: '15rem'}} >
                 <Card.Header style={styleStatus(item.status)}>{item.status}</Card.Header>
                
                <Link to={`/UpdateHotel/${item._id}`}>
                <Card.Img variant="top" src={item.images.length === 0 ? Icon : item.images[0].sourceBase64 }  height="130"  />
                </Link>
              
                <Card.Title>{item.name}</Card.Title>
                <Card.Text>
                {"ที่อยู่ : "+item.address}
          
                </Card.Text>
                <Card.Text>
                {"คำอธิบาย : "+item.shortDetail}
                </Card.Text>
              
            </Card>
        )
    })

    return (
        <div>

            Main Page
            <div className="d-flex align-content-end flex-wrap bd-highlight example-parent" >
                {hotellist}
                
            

               

            </div>

         
            
           

        </div>
    )
}

export default Mainpage