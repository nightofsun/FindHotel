import React, { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import Icon from '../Picture/emtryImage.png'
import '../App.css'
function VeiwHotel() {

    const params = useParams()
    const [listHotel, setListhotel] = useState([])


    async function loadPic() {

        const res = await fetch(`/loadViewhotel/${params.id}`);
        res.json()
            .then(res => setListhotel(res))

    }

    useEffect(() => {

        loadPic();

    }, [])

    function deletePost() {
        fetch(`/deleteHotel/${params.id}`)
            .then(res => console.log(res))
    }

    function Picture(pic) {
       
        return pic.map(e => <div > <img key={e} srcSet={e.sourceBase64} width="150" height="130" style={{ margin: "6px" }} /></div>)
    }

    const hotellist = listHotel.map(item => {
        return (

            <div>
                <div key={item._id} style={{ display: "flex", flexdirection: "row", flexwrap: "wrap", }} >
                  
                    {item.images.length === 0 ? <img srcSet={Icon} width="150" height="130" /> : Picture(item.images)}

                </div>
                <div className="name">{item.name}</div>
                <div className="address">{item.description}</div>
                <div className="shortDetail">{item.shortDetail}</div>
            </div>
        )
    })

  
    return (
        <div>


            {hotellist}

            <Link to={`/UpdateHotel/${params.id}`}>
                <button >updatePost</button>
            </Link>

            <Link to="/">
                <button onClick={deletePost}>deletePost</button>
            </Link>



        </div>
    )
}

export default VeiwHotel
